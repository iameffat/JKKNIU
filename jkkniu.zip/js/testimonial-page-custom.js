$(function(){
	'use strict';

	$(".testimonial-page").owlCarousel({
		items: 1,
		navigation: true,
		slideSpeed: 1000,
		dots: true,
		paginationSpeed: 400,
		singleItem: true,
		
		loop: true
	});


});