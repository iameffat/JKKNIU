<!DOCTYPE html>
<html lang="zxx">
    
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Online Tools</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
		<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->

	<!-- features home -->
	<div class="features-home segments2">
		<div class="container-pd">
	
			<br>
			
			<div class="row">
				<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="payment.php"><h6><center><i class="fa fa-money"></i><br><b>অনলাইন ফি পেমেন্ট</b></center></h6></a>
					</div>
				</div>
				<div class="col-6 px-2">
					<div class="content b-shadow">
							<a href="https://nuadmission.online"><h6><center><i class="fa fa-university"></i><br><b>জেএসটি ভর্তি</b></center></h6></a>
					</div>
				</div>
			</div>
			<div class="row">
			<div class="col-6 px-2">
					<div class="content b-shadow">
							<a href="https://jkkniu.edu.bd/downloadable-forms/"><h6><center><i class="fa fa-cloud-download"></i><br><b>গুরুত্বপূর্ণ ফর্ম</b></center></h6></a>
					</div>
				</div>
				<div class="col-6 px-2">
					<div class="content b-shadow">
							<a href="https://hosting.bdren.net.bd:2096"><h6><center><i class="fa fa-envelope"></i><br><b>ওয়েব মেইল</b></center></h6></a>
					</div>
				</div>
			</div>
			<div class="row">
					<div class="col-6 px-2">
					<div class="content b-shadow">
							<a href="age-calculator.php"><h6><center><i class="fa fa-calculator"></i><br><b>বয়স ক্যালকুলেটর</b></center></h6></a>
					</div>
				</div>
				<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="https://www.resizepixel.com/"><h6><center><i class="fa fa-file-image-o"></i><br><b>ইমেজ রিসাইজার</b></center></h6></a>
					</div>
				</div>	
			</div>
			
			<div class="row">
			<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="https://www.pdf-merge.com/"><h6><center><i class="fa fa-file-pdf-o"></i><br><b>পিডিএফ মার্জ</b></center></h6></a>
					</div>
				</div>
			<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="https://imagetopdf.com/"><h6><center><i class="fa fa-file-image-o"></i><br><b>ইমেজ টু পিডিএফ</b></center></h6></a>
					</div>
				</div>	
			</div>
			
			<div class="row">
			<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="https://bsbk.portal.gov.bd/apps/bangla-converter/index.html"><h6><center><i class="fa fa-exchange"></i><br><b>অভ্র-টু-বিজয় কনভার্টার</b></center></h6></a>
					</div>
				</div>
			<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="https://quran.com/"><h6><center><i class="fa fa-book"></i><br><b>অনলাইন কুরআন</b></center></h6></a>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-6 px-2">
					<div class="content b-shadow">
						<a href="https://www.hadithbd.com/hadith/"><h6><center><i class="fa fa-book"></i><br><b>অনলাইন হাদিস</b></center></h6></a>
					</div>
				</div>
			</div>
			<br>
		</div>
	</div>
	<!-- and features home -->

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/lightbox.js"></script>
	<script src="js/jquery.filterizr.js"></script>
	<script src="js/imagesloaded.pkgd.min.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>