<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Fire Services</title>

	<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700,900" rel="stylesheet">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
			<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->

	<!-- features -->
	
	
	<div class="features segments-page">
	
	<div class="wrap-title">
				<center><h4><b>ইমারজেন্সি ফায়ার সার্ভিস</b></h4>
				<p>ত্রিশাল, ময়মনসিংহ এবং ভালুকার ফায়ার সার্ভিস নম্বরসমূহ।</p></center>
			</div>
		<div class="container-pd">
			<div class="row">
				<div class="col-6 px-2">
					<div class="content b-shadow">
						<i class="fa fa-fire"></i>
						<h4>ত্রিশাল</h4>
						<p>+8801730879000</p>
					<a href="tel:+8801730879000">	<div class="contents center">
							<button class="button button-custom waves-effect blue b-shadow">Call Now</button>
						</div>
						</a>
					</div>
				</div>
				<div class="col-6 px-2">
					<div class="content b-shadow">
						<i class="fa fa-fire"></i>
						<h4>ময়মনসিংহ</h4>
						<p>+8801730002353</p>
						<a href="tel:+8801730002353"> <div class="contents center">
							<button class="button button-custom waves-effect blue b-shadow">Call Now</button>
						</div>
						</a>
					</div>
				</div>
			</div>
			</div>	
			<br/>
			<div class="container-pd">
			<div class="row">
				<div class="col-6 px-2">
					<div class="content b-shadow">
						<i class="fa fa-fire"></i>
						<h4>ভালুকা </h4>
						<p>+8801730002368</p>
					<a href="tel:+8801730002368">	<div class="contents center">
							<button class="button button-custom waves-effect blue b-shadow">Call Now</button>
						</div>
						</a>
					</div>
				</div>
			<div class="col-6 px-2">
					<div class="content b-shadow">
						<i class="fa fa-fire"></i>
						<h4>৯৯৯ </h4>
						<p>999</p>
					<a href="tel:999">	<div class="contents center">
							<button class="button button-custom waves-effect blue b-shadow">Call Now</button>
						</div>
						</a>
					</div>
				</div>
			</div>
			</div>	
			
	
		
		</div>
		
	</div>
	<!-- end features -->

	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>