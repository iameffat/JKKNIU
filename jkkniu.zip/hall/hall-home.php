<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="../images/favicon.png">
	<title>Students Hall</title>

	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.css">
	<link rel="stylesheet" href="../css/line-awesome.css">
	<link rel="stylesheet" href="../css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">
	<link rel="stylesheet" href="../css/animsition.css">
	<link rel="stylesheet" href="../css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
			<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
<br>
	<!-- card -->
	<div class="wrap-card segments-page">
		<div class="container">
<div class="wrap-content b-shadow">
			
			
					
					
              <div class="container-pd">
				<div class="row">
					
					<div class="col-6 px-2">
					<a href="../hall/agnibina.html">
						<div class="card b-shadow">
							<img src="../images/hall/agni.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>অগ্নিবীণা হল</b></h5>
								<p class="card-text">হলের প্রভোস্ট, হাউজ টিউটর এবং কর্মকর্তা, কর্মচারীদের নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					<div class="col-6 px-2">
					<a href="../hall/dolonchapa.html">
						<div class="card b-shadow">
							<img src="../images/hall/dchapa.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>দোলনচাঁপা হল</b></h5>
								<p class="card-text">হলের প্রভোস্ট, হাউজ টিউটর এবং কর্মকর্তা, কর্মচারীদের নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					
				</div>
			</div>
				

		
              <div class="container-pd">
				<div class="row">
					
					<div class="col-6 px-2">
					<a href="../hall/bangabandhu.html">
						<div class="card b-shadow">
							<img src="../images/gallery/8.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান হল</b></h5>
								<p class="card-text">হলের প্রভোস্ট, হাউজ টিউটর এবং কর্মকর্তা, কর্মচারীদের নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					<div class="col-6 px-2">
					<a href="../hall/bangamata.html">
						<div class="card b-shadow">
							<img src="../images/gallery/9.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>বঙ্গমাতা বেগম ফজিলাতুন্নেছা মুজিব হল</b></h5>
								<p class="card-text">হলের প্রভোস্ট, হাউজ টিউটর এবং কর্মকর্তা, কর্মচারীদের নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					
				</div>
			</div>





				
	
	</div>		
	</div>
	</div>
	<!-- end card -->

	<script src="../js/jquery.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/lightbox.js"></script>
	<script src="../js/animsition.min.js"></script>
	<script src="../js/animsition-custom.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/main.js"></script>

</body>
</html>