<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="../images/favicon.png">
	<title>Administration Corner</title>

	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.css">
	<link rel="stylesheet" href="../css/line-awesome.css">
	<link rel="stylesheet" href="../css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">
	<link rel="stylesheet" href="../css/animsition.css">
	<link rel="stylesheet" href="../css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
	
	<div class="tabs b-shadow"><center><p><b>পরিবর্তিত সকল তথ্য (বিশ্ববিদ্যালয় হতে প্রকাশিত) নতুন একাডেমিক ডায়েরি প্রকাশের সাথে সংগতি রেখে যুক্ত করা হবে।</b></p></center></div>
	
	<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>প্রশাসনিক কর্ণার</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../administration/vc-office.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ভাইস চ্যান্সেলর অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../administration/treasurer.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ট্রেজারার অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
		
		
                       <div class="list segments-page2">
		<div class="container">
			<a href="../administration/registrar.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> রেজিস্ট্রার অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>				
				
					<div class="list segments-page2">
		<div class="container">
			<a href="../administration/public-relations.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> জনসংযোগ দপ্তর</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
				<div class="list segments-page2">
		<div class="container">
			<a href="../student-counciling.php"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ছাত্র পরামর্শ ও নির্দেশনা দপ্তর</h5>
				</div>
			</div></a>
			</div>
		</div>		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../proctor-office.php"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> প্রক্টর অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../administration/controller-exam.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> পরীক্ষা নিয়ন্ত্রক অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../administration/accounts-finance.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> অর্থ ও হিসাব দপ্তর</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/engineering.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> প্রকৌশল দপ্তর</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../administration/project-director.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> প্রকল্প পরিচালকের কার্যালয়</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../administration/physical-education.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> শারীরিক শিক্ষা দপ্তর</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/transportation.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> পরিবহন পুল</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/planning.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> পরিকল্পনা, উন্নয়ন ও ওয়ার্কস অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/central-library.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> কেন্দ্রীয় গ্রন্থাগার</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/nazrul-studies.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ইন্সটিটিউট অব নজরুল স্টাডিজ</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/research.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> গবেষণা ও সম্প্রসারণ দপ্তর</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
			<div class="list segments-page2">
		<div class="container">
			<a href="../administration/iqac.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ইন্সটিটিউশনাল কোয়ালিটি অ্যাশুরেন্স সেল</h5>
				</div>
			</div></a>
			</div>
		</div>	
										
						
</div></div>
</div>
	
	
	



	

    <script> (function () {
	var observer = new IntersectionObserver(onIntersect);

	document.querySelectorAll("[data-lazy]").forEach((img) => {
		observer.observe(img);
	});

	function onIntersect(entries) {
		entries.forEach((entry) => {
			if (entry.target.getAttribute("data-processed") || !entry.isIntersecting)
				return true;
			entry.target.setAttribute("src", entry.target.getAttribute("data-src"));
			entry.target.setAttribute("data-processed", true);
		});
	}
})();
</script>        
	<script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/lightbox.js"></script>
	<script src="../js/animsition.min.js"></script>
	<script src="../js/animsition-custom.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/styleswitcher.js"></script>
	<script src="../js/main.js"></script>

</body>
</html>