<!DOCTYPE html>
<html lang="zxx">
    
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>JKKNIU</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">
	
	
	
	<style>
img {
  max-width: auto%;
  height: auto;
}
</style>




</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">

	
	<!-- slide -->
	
			<div class="slide">
		<div class="slide-show-home owl-carousel owl-theme">
			
			<div class="slide-content">
				<div class="mask"></div>
				<img src="images/slider-home1.jpg" alt="">
				<div class="intro-caption">
					<h2>জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয়</h2>
				</div>
			</div>
			
			<div class="slide-content">
				<img src="images/slider-home3.jpg" alt="">
			</div>
			
			<div class="slide-content">
				<img src="images/slider-home2.jpg" alt="">
			</div>
			
		</div>
	</div>
	
	<!-- end slide -->


<!-- filter home 0 -->
	<div class="filter-home segments">
		<div class="container-pd">
		
		
			<div class="row">
				<div class="col-4 px-2">
					<a href="bus.php">
						<div class="content b-shadow">
							<i class="fa fa-bus"></i>
							<h6>বাস <br/> শিডিউল</h6>
						</div>
					</a>
				</div>
				<div class="col-4 px-2">
					<a href="important-contact.php">
						<div class="content b-shadow">
							<i class="fa fa-phone"></i>
							<h6>গুরুত্বপূর্ণ <br/> নম্বরসমূহ</h6>
						</div>
					</a>
				</div>
				<div class="col-4 px-2">
					<a href="vacation.php">
						<div class="content b-shadow">
							<i class="fa fa-list-alt"></i>
							<h6>ছুটির <br/>তালিকা</h6>
						</div>
					</a>
				</div>
			</div>

			
			
			
			
			<div class="row">
				<div class="col-4 px-2">
					<a href="https://jkkniu.edu.bd/career/">
						<div class="content b-shadow">
							<i class="fa fa-graduation-cap"></i>
							<h6>নিয়োগ<br/>বিজ্ঞপ্তি</h6>
						</div>
					</a>
				</div>
				<div class="col-4 px-2">
					<a href="https://jkkniu.edu.bd/notice-board-2/">
						<div class="content b-shadow">
							<i class="fa fa-bullhorn"></i>
							<h6>নোটিশ <br/>বোর্ড</h6>
						</div>
					</a>
				</div>
				<div class="col-4 px-2">
					<a href="https://jkkniu.edu.bd/news/">
						<div class="content b-shadow">
							<i class="fa fa-newspaper-o"></i>
							<h6>নিউজ <br/>আপডেট</h6>
						</div>
					</a>
				</div>
			</div>
			
			

			
				<div class="row">
				<div class="col-4 px-2">
				<a href="online.php">
				
						<div class="content b-shadow">
							<i class="fa fa-cog"></i>
							<h6>অনলাইন<br/>টুলস</h6>
						</div>
					</a>
				</div>
				
				
				<div class="col-4 px-2">
					<a href="photo-gallery.php">
						<div class="content b-shadow">
							<i class="fa fa-photo"></i>
							<h6>ফটো <br/>গ্যালারি</h6>
						</div>
					</a>
				</div>
				<div class="col-4 px-2">
					<a href="about-jkkniu.php">
						<div class="content b-shadow">
							<i class="fa fa-info"></i>
							<h6>জাককানইবি <br/>সম্পর্কে</h6>
						</div>
					</a>
				</div>
			</div>
			
			
			
			
		</div>
	</div>
	<!-- end filter home -->
	


	
	<footer class="footer-home">
		<div class="by">
			<p><a href="about-dev.php"> app.effat.me</a></p>
		</div>
	</footer>
	

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
	<script src="js/jquery.big-slide.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>