<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" href="images/favicon.png">
    <title>Online Fee Payment</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/lightbox.css">
    <link rel="stylesheet" href="css/line-awesome.css">
    <link rel="stylesheet" href="css/line-awesome-font-awesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body onmousedown="return false" onselectstart="return false">

	<!-- navbar -->
		<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->




    <!-- loader -->
    <div class="wrap-preloader">
        <div class="preloader">
            <div class="spinner-border" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
    </div>
    <!-- end loader -->

    <!-- home walkthrough -->
    <div class="home-walkthrough segments">
        <div class="container">
            <h3>জাককানইবি অনলাইন ফি পেমেন্ট</h3>
            <div class="walkthrough-slider owl-carousel owl-theme">
                <div class="item">
                    <div class="wrap-content">
                        <div class="content b-shadow">
                            <div class="icon">
                                <i class="fa fa-money b-shadow"></i>
                            </div>
                            <div class="text">
                                <h2>সোনালি ব্যাংক বিল পেমেন্ট সিস্টেম।</h2>
                                
                            </div>
                        </div>
                    </div>
                </div>
                
            </div><p>বিশ্ববিদ্যালয়ের শিক্ষার্থীদের সেমিস্টার ফি, ভর্তি ফি এবং অন্যান্য সকল ফি এখন অনলাইনেই দেওয়া যাচ্ছে। প্রায় সকল ধরনের পেমেন্ট গেটওয়ে (বিকাশ, রকেট, নগদ এবং ব্যাংক ইত্যাদি) এর মাধ্যমে ফি দেওয়া যাবে। </p>
			<hr>
			<p>পরবর্তী পেইজ অর্থাৎ পেমেন্ট পেইজটি লোড হতে কিছু সময় লাগতে পারে। সম্পুর্ণ লোড হওয়ার পর রেজিঃ নম্বর প্রবেশ করবেন।</p>
            <div class="wrap-started">
                <a class="b-shadow " href="https://sbl.com.bd:7070/JKKNIU/Home/">Go to Payment Page</a>
            </div>
        </div>
    </div>
    <!-- end home walkthrough -->

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>