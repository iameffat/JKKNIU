<!DOCTYPE html>
<html lang="zxx">
    
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Photo Gallery</title>
	
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
<br/>
	<!-- gallery -->
	<div class="gallery segments-page">
		<div class="container">
			<div class="tabs b-shadow">
				<div class="nav nav-tabs justify-content-center" id="nav-tab" role="tablist">
					<a href="#nav-gallery2" class="nav-item nav-link active" id="nav-gallery2-tab" data-toggle="tab" role="tab" aria-controls="nav-gallery2" aria-selected="true"><i class="fa fa-th-large"></i></a>
					<a href="#nav-gallery3" class="nav-item nav-link" id="nav-gallery3-tab" data-toggle="tab" role="tab" aria-controls="nav-gallery3" aria-selected="false">
						<span></span>
					</a>
				</div>
			</div>
			<div class="tab-content" id="nav-tabContent">
				<div class="tab-pane fade show active" id="nav-gallery2" role="tabpanel" aria-labelledby="nav-gallery2-tab">
					<div class="container-pd">
						<div class="row">
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/1.jpg" data-lightbox="gallery2">
										<img src="images/gallery/1.jpg" alt="">
									</a>
								</div>
							</div>
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/2.jpg" data-lightbox="gallery2">
										<img src="images/gallery/2.jpg" alt="">
									</a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/3.jpg" data-lightbox="gallery2">
										<img src="images/gallery/3.jpg" alt="">
									</a>
								</div>
							</div>
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/4.jpg" data-lightbox="gallery2">
										<img src="images/gallery/4.jpg" alt="">
									</a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/5.jpg" data-lightbox="gallery2">
										<img src="images/gallery/5.jpg" alt="">
									</a>
								</div>
							</div>
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/6.jpg" data-lightbox="gallery2">
										<img src="images/gallery/6.jpg" alt="">
									</a>
								</div>
							</div>
						</div>
						
							<div class="row">
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/7.jpg" data-lightbox="gallery2">
										<img src="images/gallery/7.jpg" alt="">
									</a>
								</div>
							</div>
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/8.jpg" data-lightbox="gallery2">
										<img src="images/gallery/8.jpg" alt="">
									</a>
								</div>
							</div>
						</div>
						
							<div class="row">
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/gallery/9.jpg" data-lightbox="gallery2">
										<img src="images/gallery/9.jpg" alt="">
									</a>
								</div>
							</div>
							<div class="col s6 px-2">
								<div class="content">
									<a href="images/slider-home2.jpg" data-lightbox="gallery2">
										<img src="images/slider-home2.jpg" alt="">
									</a>
								</div>
							</div>
						</div>
						
						
						
					</div>
				</div>
				
				
				
				<div class="tab-pane fade" id="nav-gallery3" role="tabpanel" aria-labelledby="nav-gallery3-tab">
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/1.jpg" data-lightbox="gallery3">
									<img src="images/gallery/1.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/2.jpg" data-lightbox="gallery3">
									<img src="images/gallery/2.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/3.jpg" data-lightbox="gallery3">
									<img src="images/gallery/3.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/4.jpg" data-lightbox="gallery3">
									<img src="images/gallery/4.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/5.jpg" data-lightbox="gallery3">
									<img src="images/gallery/5.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/6.jpg" data-lightbox="gallery3">
									<img src="images/gallery/6.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/7.jpg" data-lightbox="gallery3">
									<img src="images/gallery/7.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/8.jpg" data-lightbox="gallery3">
									<img src="images/gallery/8.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/gallery/9.jpg" data-lightbox="gallery3">
									<img src="images/gallery/9.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-12">
							<div class="content">
								<a href="images/slider-home2.jpg" data-lightbox="gallery3">
									<img src="images/slider-home2.jpg" alt="">
								</a>
							</div>
						</div>
					</div>
				
					
				</div>
			</div>
		</div>
		
		<p align="center">Photo Credit: JKKNIU Press Club, Mahmudul Hasan Hridoy, Film and Photography Club, Taieb Ar Rafi, MN Photography and SM Tahazzadul Islam Uranto.</p>
		
		
	</div>
	<!-- end gallery -->

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>