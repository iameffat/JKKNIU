<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Age Calculator</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">
	
	
	
	<style media="screen" type="text/css">

.cal-container {
 width: 100%;
}
#age-calculator {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 2px solid #BEBEBE;
  
}

.calc {
    border-color: #AAAAAA #999999 #929292 #AAAAAA;
    border-style: solid;
    border-width: 2.5px; 
    padding:3px;
	font-weight: bold;
}
.calc:active {
    border-color: #AAAAAA #999999 #929292 #AAAAAA;
    border-style: solid;
    border-width: 1px;
}
.maintdclass{
text-align:center;

}

.innerc{
    width:60px;
}

</style>
	
	

</head>
	
	<!-- navbar -->
		<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->

	<!-- tabs -->
	
<body class="animsition" onload="wr_document()">


<div class="container">
<div id="calculator-container">

<table border="0" cellpadding="0" cellspacing="0" style="width: 100%px;">
<tbody>
<tr>
<td valign="top">

<div class="tabs b-shadow">
<h3 style="padding-top: 10px; text-align:center;">
<b>বয়স বের করার ক্যালকুলেটর</b></h3><hr>
<center><span>বিশ্ববিদ্যালয়ের ফর্ম ফিলাপে, চাকরির আবেদনের ক্ষেত্রে অনেক সময় বয়স বের করতে হয়।  এই  <b>Age Calculator</b> এর মাধ্যমে আপনি আপনার কাঙ্ক্ষিত বয়স বের করতে পারবেন। </span><br /><br/></center>
</div>

<div id="age-calculator">
<table align="center" class="maintdclass">
<tbody>
<tr>
<td colspan="2">
<table>
<tbody>
<tr>
<td>
<form name="cir">
<table>
<tbody>
<tr>
<td colspan="2">
<br /> <b>
বিজ্ঞপ্তিতে উল্লিখিত তারিখঃ </b>
</td>
</tr>
<tr>
<td align="center" colspan="2">
দিন -
<input class="innerc" name="len11" onkeyup="checkday(this)" size="2" type="text" value="" />
মাস -
<input class="innerc resform" name="len12" onkeyup="checkmon(this)" size="2" type="text" value="" />
বছর -
<input class="innerc resform" name="len13" onkeyup="checkyear(this)" size="4" type="text" value="" />
<br />
<br />
</td>
</tr>
<tr>
<td colspan="2"> <b> আপনার জন্ম তারিখঃ </b></td>
</tr>
<tr>
<td align="center" colspan="2">
দিন -
<input class="innerc resform" name="len21" onkeyup="checkday(this)" size="2" type="text" />
মাস -
<input class="innerc resform" name="len22" onkeyup="checkmon(this)" size="2" type="text" />
বছর - 
<input class="innerc resform" name="len23" onkeyup="checkyear(this)" size="4" type="text" />
<br />
<br />
<input class="calc" name="but" onclick="calage()" type="button" value=" বয়স বের করুন  " />
<br />
<br />
</td>
</tr>
<tr>
<td align="left" class="form" width="100%">
<b> </b>
</td>
</tr>
</tbody>
</table>
<table>
<tbody>
<tr>
<td>

</td>
<b> বিজ্ঞপ্তিতে উল্লিখিত তারিখে আপনার বয়সঃ  </b>
<td>
<input class="resform" name="val" readonly="" size="36" type="text" />
</td>
</tr>
<tr>
<td></td>

</tr>
</tbody>
</table>
</form>
</td>
</tr>
</tbody>
</table>
<br />
</td>
<td> </td>
</tr>
<tr>
<td align="left" colspan="2"> </td>
<td> </td>
</tr>
</tbody>
</table>

<br />
</div>
</td>
</tr>
</tbody>
</table>
</div>
</div>




	
	<!-- end tabs -->
	
	
	<script type="text/javascript">

function wr_document()
{
var w=new Date();
var s_d=w.getDate();
var s_m=w.getMonth()+1;
var s_y=w.getFullYear();

 
document.cir.len11.value=s_d;
document.cir.len12.value=s_m;
document.cir.len13.value=s_y;
}

function isNum(arg)
{
var args = arg;
if (args == "" || args == null || args.length == 0)
{
return false;
}
args = args.toString();
for (var i = 0; i<args.length; i++)
{
if ((args.substring(i,i+1) < "0" || args.substring(i, i+1) > "9") && args.substring(i, i+1) != ".")
{
return false;
}
}
return true;
}
function checkday(aa)
{
var val = aa.value;
var valc = val.substring(0,1);
if(val.length>0 && val.length<3)
{
if(!isNum(val) || val == 0)
{
aa.value="";
}
else if( val < 1 || val > 31)
{
aa.value=valc;
}
}
else if(val.length>2)
{
val = val.substring(0, 2);
aa.value=val;
}
}
function checkmon(aa)
{
var val = aa.value;
var valc = val.substring(0,1);
if(val.length>0 && val.length<3)
{
if(!isNum(val) || val == 0)
{
aa.value="";
}
else if(val < 1 || val > 12)
{
aa.value=valc;
}
}
else if(val.length>2)
{
val = val.substring(0, 2);
aa.value=val;
}
}
function checkyear(aa)
{
var val = aa.value;
var valc = val.substring(0,(val.length-1));
if(val.length>0 && val.length<7)
{
if(!isNum(val) || val == 0)
{
aa.value=valc;
}
else if(val < 1 || val>275759)
{
aa.value="";
}
}
else if(val.length>4)
{
aa.value=valc;
}
}
function checkleapyear(datea)
{
if(datea.getYear()%4 == 0)
{
if(datea.getYear()% 10 != 0)
{
return true;
}
else
{
if(datea.getYear()% 400 == 0)
return true;
else
return false;
}
}
return false;
}
function DaysInMonth(Y, M) {
with (new Date(Y, M, 1, 12)) {
setDate(0);
return getDate();
}
}
function datediff(date1, date2) {
var y1 = date1.getFullYear(), m1 = date1.getMonth(), d1 = date1.getDate(),
y2 = date2.getFullYear(), m2 = date2.getMonth(), d2 = date2.getDate();
if (d1 < d2) {
m1--;
d1 += DaysInMonth(y2, m2);
}
if (m1 < m2) {
y1--;
m1 += 12;
}
return [y1 - y2, m1 - m2, d1 - d2];
}
function calage()
{
var curday = document.cir.len11.value;
var curmon = document.cir.len12.value;
var curyear = document.cir.len13.value;
var calday = document.cir.len21.value;
var calmon = document.cir.len22.value;
var calyear = document.cir.len23.value;
if(curday == "" || curmon=="" || curyear=="" || calday=="" || calmon=="" || calyear=="")
{
alert("Please fill all the values and click here again");
}
else if(curday == calday && curmon==calmon && curyear==calyear)
{
alert("Today your birthday & Your age is 0 years old")
}
else
{
var curd = new Date(curyear,curmon-1,curday);
var cald = new Date(calyear,calmon-1,calday);
var diff = Date.UTC(curyear,curmon,curday,0,0,0)
- Date.UTC(calyear,calmon,calday,0,0,0);
var dife = datediff(curd,cald);
document.cir.val.value=dife[0]+" years, "+dife[1]+" months and "+dife[2]+" days";
var secleft = diff/1000/60;
document.cir.val3.value=secleft+" minutes since your birth";
var hrsleft = secleft/60;
document.cir.val2.value=hrsleft+" hours since your birth";
var daysleft = hrsleft/24;
document.cir.val1.value=daysleft+" days since your birth";
//alert(""+parseInt(calyear)+"--"+dife[0]+"--"+1);
var as = parseInt(calyear)+dife[0]+1;
var diff = Date.UTC(as,calmon,calday,0,0,0)
- Date.UTC(curyear,curmon,curday,0,0,0);
var datee = diff/1000/60/60/24;
document.cir.val4.value=datee+" days left for your next birthday";
}
}
function color(test)
{
for(var j=7; j<12; j++)
{
var myI=document.getElementsByTagName("input").item(j);
//myI.setAttribute("style",ch);
myI.style.backgroundColor=test;
}
}
function color1(test)
{
var myI=document.getElementsByTagName("table").item(0);
//myI.setAttribute("style",ch);
myI.style.backgroundColor=test;
}
</script>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/lightbox.js"></script>
	<script src="js/jquery.filterizr.js"></script>
	<script src="js/imagesloaded.pkgd.min.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>