<!DOCTYPE html>
<html lang="zxx">
    
    
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Vacation List</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">


<style>
#customers {
  font-family: SolaimanLipi;
  border-collapse: collapse;
  width: 100%;
  color: black!important;
}

#customers td, #customers th {
  border: 1.5px solid #ddd;
  padding: 7px;
}
#
#customers tr:nth-child(even){background-color: #8f5353;}

#customers tr:hover {background-color: #d3edd4; color: black;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #04AA6D;
  color: white;
}

.rback{
		background:#ffffff;
		}
		.texttable{
		 text-align:center;
		}


</style>



</head>

<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
			<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->

	<!-- tabs -->
	<div class="tabs-page segments-page">
		<div class="container">
			<div class="tabs b-shadow">
				<div class="nav nav-tabs justify-content-center" id="nav-tab" role="tablist">
					<a href="#nav-tabs1" class="nav-item nav-link active" id="nav-tabs1-tab" data-toggle="tab" role="tab" aria-controls="nav-tabs1" aria-selected="true">ক্লাস ছুটি</a>
					<a href="#nav-tabs2" class="nav-item nav-link" id="nav-tabs2-tab" data-toggle="tab" role="tab" aria-controls="nav-tabs2" aria-selected="false">অফিস ছুটি</a>
				</div>
			</div>
			<div class="tab-content b-shadow" id="nav-tabContent">
				<div class="tab-pane fade show active" id="nav-tabs1" role="tabpanel" aria-labelledby="nav-tabs1-tab">
					<div class="wrap-title">
				<h3><center>ক্লাস ছুটি ২০২৩</center></h3>
			</div>
			<div class="wrap-content b-shadow">
<table id="customers">
<tbody>
<thead>
<tr style="height: 37px;">
<th style="width: 25%; height: 37px;"><strong>বিষয়</strong></th>
<th style="width: 25%; height: 37px;"><strong>তারিখ</strong></th>
<th style="width: 25%; height: 37px;"><strong>বার</strong></th>
<th style="width: 25%; height: 37px;"><strong>দিন</strong></th>
</tr>
</thead>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শ্রী শ্রী সরস্বতী পূজা</td>
<td style="width: 25%; height: 37px;">২৬/০১/২০২৩</td>
<td style="width: 25%; height: 37px;">বৃহঃ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*শব-ই-মেরাজ</td>
<td style="width: 25%; height: 37px;">১৯/০২/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 61px;">
<td style="width: 25%; height: 61px;">মহান শহীদ দিবস ও আন্তর্জাতিক মাতৃভাষা দিবস</td>
<td style="width: 25%; height: 61px;">২১/০২/২০২৩</td>
<td style="width: 25%; height: 61px;">মঙ্গল</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*পবিত্র শব-ই-বরাত, শ্রী কৃষ্ণের দোলযাত্রা</td>
<td style="width: 25%; height: 37px;">০৮/০৩/২০২৩</td>
<td style="width: 25%; height: 37px;">বুধ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 85px;">
<td style="width: 25%; height: 85px;">জাতির পিতা বঙ্গবন্ধু শেখ মুজিবুর রহমানের জন্ম দিবস ও জাতীয় শিশু দিবস</td>
<td style="width: 25%; height: 85px;">১৭/০৩/২০২৩</td>
<td style="width: 25%; height: 85px;">শুক্র</td>
<td style="width: 25%; height: 85px;">০০</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">মহান স্বাধীনতা দিবস ও জাতীয় দিবস</td>
<td style="width: 25%; height: 61px;">২৬/০৩/২০২৩</td>
<td style="width: 25%; height: 61px;">রবি</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">ইস্টার সানডে</td>
<td style="width: 25%; height: 37px;">০৯/০৪/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">পহেলা বৈশাখ</td>
<td style="width: 25%; height: 37px;">১৪/০৪/২০২৩</td>
<td style="width: 25%; height: 37px;">শুক্র</td>
<td style="width: 25%; height: 37px;">০০</td>
</tr>
<tr class="texttable rback" style="height: 85px;">
<td style="width: 25%; height: 85px;">*পবিত্র শব-ই-কদর, *জুমাতুল বিদা, *পবিত্র ঈদ-উল-ফিতর</td>
<td style="width: 25%; height: 85px;">১৬/০৪/২০২৩ - ২৭/০৪/২০২৩</td>
<td style="width: 25%; height: 85px;">রবি-বৃহঃ</td>
<td style="width: 25%; height: 85px;">১২</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">মে দিবস</td>
<td style="width: 25%; height: 61px;">০১/০৫/২০২৩</td>
<td style="width: 25%; height: 61px;">সোম</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">*বৌদ্ধ পূর্ণিমা (বৈশাখী পূর্ণিমা)</td>
<td style="width: 25%; height: 61px;">০৪/০৫/২০২৩</td>
<td style="width: 25%; height: 61px;">বৃহঃ</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 61px;">
<td style="width: 25%; height: 61px;">*পবিত্র ঈদ-উল-আযহা, গ্রীষ্মকালীন অবকাশ</td>
<td style="width: 25%; height: 61px;">১১/০৬/২০২৩ - ০৬/০৭/২০২৩</td>
<td style="width: 25%; height: 61px;">রবি-বৃহঃ</td>
<td style="width: 25%; height: 61px;">২৬</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*হিজরি নববর্ষ</td>
<td style="width: 25%; height: 37px;">১৮/০৭/২০২৩</td>
<td style="width: 25%; height: 37px;">মঙ্গল</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">*আশুরা (মহররম)</td>
<td style="width: 25%; height: 37px;">২৯/০৭/২০২৩</td>
<td style="width: 25%; height: 37px;">শনি</td>
<td style="width: 25%; height: 37px;">০০</td>
</tr>
<tr class="texttable" style="height: 85px;">
<td style="width: 25%; height: 85px;">জাতীয় শোক দিবস (জাতির পিতা বঙ্গবন্ধু শেখ মুজিবুর রহমানের মহাপ্রয়াণ দিবস)</td>
<td style="width: 25%; height: 85px;">১৫/০৮/২০২৩</td>
<td style="width: 25%; height: 85px;">মঙ্গল</td>
<td style="width: 25%; height: 85px;">০১</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">জাতীয় কবি কাজী নজরুল ইসলামের মহাপ্রয়াণ দিবস (১২ ভাদ্র)</td>
<td style="width: 25%; height: 61px;">২৭/০৮/২০২৩</td>
<td style="width: 25%; height: 61px;">রবি</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">জন্মাষ্টমী</td>
<td style="width: 25%; height: 37px;">০৬/০৯/২০২৩</td>
<td style="width: 25%; height: 37px;">বুধ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">*আখেরি চাহার সোম্বা</td>
<td style="width: 25%; height: 37px;">১৩/০৯/২০২৩</td>
<td style="width: 25%; height: 37px;">বুধ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">*ঈদ-ই-মিলাদুন্নবী (সা.)</td>
<td style="width: 25%; height: 37px;">২৮/০৯/২০২৩</td>
<td style="width: 25%; height: 37px;">বৃহঃ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শ্রী শ্রী দূর্গাপূজা,*ফাতেহা-ই-ইয়াজদহম</td>
<td style="width: 25%; height: 37px;">২২/১০/২০২৩ - ২৬/১০/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি-বৃহঃ</td>
<td style="width: 25%; height: 37px;">০৫</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*শ্রী শ্রী শ্যামা পূজা</td>
<td style="width: 25%; height: 37px;">১২/১১/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable" class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শহীদ বুদ্ধিজীবি দিবস</td>
<td style="width: 25%; height: 37px;">১৪/১২/২০২৩</td>
<td style="width: 25%; height: 37px;">বৃহঃ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">মহান বিজয় দিবস</td>
<td style="width: 25%; height: 37px;">১৬/১২/২০২৩</td>
<td style="width: 25%; height: 37px;">শনি</td>
<td style="width: 25%; height: 37px;">০০</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শীতকালীন অবকাশ, যীশু খৃষ্টের জন্মদিন (বড়দিন)</td>
<td style="width: 25%; height: 37px;">১৮/১২/২০২৩ - ৩১/১২/২০২৩</td>
<td style="width: 25%; height: 37px;">সোম-রবি</td>
<td style="width: 25%; height: 37px;">১৪</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;"></td>
<td style="width: 25%; height: 37px;"></td>
<td style="width: 25%; height: 37px;"><strong>মোট ছুটি</strong></td>
<td style="width: 25%; height: 37px;"><strong>৭৩</strong></td>
</tr>
</tbody>
</table>
			</div>
				</div>
				
				
				<div class="tab-pane fade show" id="nav-tabs2" role="tabpanel" aria-labelledby="nav-tabs2-tab">
					<div class="wrap-title">
				<h3><center>অফিস ছুটি ২০২৩</center></h3>
			</div>
			<div class="wrap-content b-shadow">
				<table id="customers">
<tbody>
<thead>
<tr style="height: 37px;">
<th style="width: 25%; height: 37px;"><strong>বিষয়</strong></th>
<th style="width: 25%; height: 37px;"><strong>তারিখ</strong></th>
<th style="width: 25%; height: 37px;"><strong>বার</strong></th>
<th style="width: 25%; height: 37px;"><strong>দিন</strong></th>
</tr>
</thead>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শ্রী শ্রী সরস্বতী পূজা</td>
<td style="width: 25%; height: 37px;">২৬/০১/২০২৩</td>
<td style="width: 25%; height: 37px;">বৃহঃ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*শব-ই-মেরাজ</td>
<td style="width: 25%; height: 37px;">১৯/০২/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 61px;">
<td style="width: 25%; height: 61px;">মহান শহীদ দিবস ও আন্তর্জাতিক মাতৃভাষা দিবস</td>
<td style="width: 25%; height: 61px;">২১/০২/২০২৩</td>
<td style="width: 25%; height: 61px;">মঙ্গল</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*পবিত্র শব-ই-বরাত, শ্রী কৃষ্ণের দোলযাত্রা</td>
<td style="width: 25%; height: 37px;">০৮/০৩/২০২৩</td>
<td style="width: 25%; height: 37px;">বুধ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 85px;">
<td style="width: 25%; height: 85px;">জাতির পিতা বঙ্গবন্ধু শেখ মুজিবুর রহমানের জন্ম দিবস ও জাতীয় শিশু দিবস</td>
<td style="width: 25%; height: 85px;">১৭/০৩/২০২৩</td>
<td style="width: 25%; height: 85px;">শুক্র</td>
<td style="width: 25%; height: 85px;">০০</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">মহান স্বাধীনতা দিবস ও জাতীয় দিবস</td>
<td style="width: 25%; height: 61px;">২৬/০৩/২০২৩</td>
<td style="width: 25%; height: 61px;">রবি</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">ইস্টার সানডে</td>
<td style="width: 25%; height: 37px;">০৯/০৪/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">পহেলা বৈশাখ</td>
<td style="width: 25%; height: 37px;">১৪/০৪/২০২৩</td>
<td style="width: 25%; height: 37px;">শুক্র</td>
<td style="width: 25%; height: 37px;">০০</td>
</tr>
<tr class="texttable rback" style="height: 85px;">
<td style="width: 25%; height: 85px;">*পবিত্র শব-ই-কদর, *জুমাতুল বিদা, *পবিত্র ঈদ-উল-ফিতর</td>
<td style="width: 25%; height: 85px;">১৬/০৪/২০২৩ - ২৫/০৪/২০২৩</td>
<td style="width: 25%; height: 85px;">রবি-মঙ্গল</td>
<td style="width: 25%; height: 85px;">১০</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">মে দিবস</td>
<td style="width: 25%; height: 61px;">০১/০৫/২০২৩</td>
<td style="width: 25%; height: 61px;">সোম</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">*বৌদ্ধ পূর্ণিমা (বৈশাখী পূর্ণিমা)</td>
<td style="width: 25%; height: 61px;">০৪/০৫/২০২৩</td>
<td style="width: 25%; height: 61px;">বৃহঃ</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 61px;">
<td style="width: 25%; height: 61px;">*পবিত্র ঈদ-উল-আযহা, গ্রীষ্মকালীন অবকাশ</td>
<td style="width: 25%; height: 61px;">১৮/০৬/২০২৩ - ০৬/০৭/২০২৩</td>
<td style="width: 25%; height: 61px;">রবি-বৃহঃ</td>
<td style="width: 25%; height: 61px;">১৯</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*হিজরি নববর্ষ</td>
<td style="width: 25%; height: 37px;">১৮/০৭/২০২৩</td>
<td style="width: 25%; height: 37px;">মঙ্গল</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">*আশুরা (মহররম)</td>
<td style="width: 25%; height: 37px;">২৯/০৭/২০২৩</td>
<td style="width: 25%; height: 37px;">শনি</td>
<td style="width: 25%; height: 37px;">০০</td>
</tr>
<tr class="texttable" style="height: 85px;">
<td style="width: 25%; height: 85px;">জাতীয় শোক দিবস (জাতির পিতা বঙ্গবন্ধু শেখ মুজিবুর রহমানের মহাপ্রয়াণ দিবস)</td>
<td style="width: 25%; height: 85px;">১৫/০৮/২০২৩</td>
<td style="width: 25%; height: 85px;">মঙ্গল</td>
<td style="width: 25%; height: 85px;">০১</td>
</tr>
<tr class="texttable" style="height: 61px;">
<td style="width: 25%; height: 61px;">জাতীয় কবি কাজী নজরুল ইসলামের মহাপ্রয়াণ দিবস (১২ ভাদ্র)</td>
<td style="width: 25%; height: 61px;">২৭/০৮/২০২৩</td>
<td style="width: 25%; height: 61px;">রবি</td>
<td style="width: 25%; height: 61px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">জন্মাষ্টমী</td>
<td style="width: 25%; height: 37px;">০৬/০৯/২০২৩</td>
<td style="width: 25%; height: 37px;">বুধ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">*আখেরি চাহার সোম্বা</td>
<td style="width: 25%; height: 37px;">১৩/০৯/২০২৩</td>
<td style="width: 25%; height: 37px;">বুধ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">*ঈদ-ই-মিলাদুন্নবী (সা.)</td>
<td style="width: 25%; height: 37px;">২৮/০৯/২০২৩</td>
<td style="width: 25%; height: 37px;">বৃহঃ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শ্রী শ্রী দূর্গাপূজা,*ফাতেহা-ই-ইয়াজদহম</td>
<td style="width: 25%; height: 37px;">২২/১০/২০২৩ - ২৬/১০/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি-বৃহঃ</td>
<td style="width: 25%; height: 37px;">০৫</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">*শ্রী শ্রী শ্যামা পূজা</td>
<td style="width: 25%; height: 37px;">১২/১১/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable" class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শহীদ বুদ্ধিজীবি দিবস</td>
<td style="width: 25%; height: 37px;">১৪/১২/২০২৩</td>
<td style="width: 25%; height: 37px;">বৃহঃ</td>
<td style="width: 25%; height: 37px;">০১</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;">মহান বিজয় দিবস</td>
<td style="width: 25%; height: 37px;">১৬/১২/২০২৩</td>
<td style="width: 25%; height: 37px;">শনি</td>
<td style="width: 25%; height: 37px;">০০</td>
</tr>
<tr class="texttable" style="height: 37px;">
<td style="width: 25%; height: 37px;">শীতকালীন অবকাশ, যীশু খৃষ্টের জন্মদিন (বড়দিন)</td>
<td style="width: 25%; height: 37px;">২৪/১২/২০২৩ - ৩১/১২/২০২৩</td>
<td style="width: 25%; height: 37px;">রবি-রবি</td>
<td style="width: 25%; height: 37px;">০৮</td>
</tr>
<tr class="texttable rback" style="height: 37px;">
<td style="width: 25%; height: 37px;"></td>
<td style="width: 25%; height: 37px;"></td>
<td style="width: 25%; height: 37px;"><strong>মোট ছুটি</strong></td>
<td style="width: 25%; height: 37px;"><strong>৫৮</strong></td>
</tr>
</tbody>
</table>
			</div>
			
				</div>
				
			</div>
			
			<p>*চাঁদ দেখার উপর নির্ভরশীল। 
			<br/>শুক্র ও শনিবার জাককানইবির সাপ্তাহিক ছুটি। </p>
			
		</div>
	</div>
	
	<!-- end tabs -->

	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>