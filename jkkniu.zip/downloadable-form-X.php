<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Downloadable Forms</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
	
	<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
<br>

						<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Web-mail-For-student-3.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Webmail Application Form for Students</h5>
				</div>
			</div></a>
			</div>
		</div>
		
		<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/EMBA-Application-Form.doc-Summer-2021.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> EMBA Application Form Summer-2021</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
		
		
                       <div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Officer-21.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Officer Form</h5>
				</div>
			</div></a>
			</div>
		</div>				
				
					<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Teacher-21.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Teacher Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
				<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Postgraduate-Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Postgraduate Form</h5>
				</div>
			</div></a>
			</div>
		</div>		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Undergraduate-Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Undergraduate Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Student-ID-Card-Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Student ID Card Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Admission-Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> EMBA Admission Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
			<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Web-mail-For-Teachers-Officer-1.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Webmail Application form for Teachers and Officers</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/ACR-Employee-form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> ACR Form for Employee</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Employ-Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Employee Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Confirmation.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Confirmation Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
			<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Police-Verification.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Police Verification</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Upgradation.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Up gradation Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
		
			<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/NOC_Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> NOC Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
		
			<div class="list segments-page2">
		<div class="container">
			<a href="http://jkkniu.edu.bd/wp-content/uploads/Leave-Form.pdf"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-download"></i> Leave Application Form</h5>
				</div>
			</div></a>
			</div>
		</div>	
										
						
</div></div>
</div>
	
	
	



	

    <script> (function () {
	var observer = new IntersectionObserver(onIntersect);

	document.querySelectorAll("[data-lazy]").forEach((img) => {
		observer.observe(img);
	});

	function onIntersect(entries) {
		entries.forEach((entry) => {
			if (entry.target.getAttribute("data-processed") || !entry.isIntersecting)
				return true;
			entry.target.setAttribute("src", entry.target.getAttribute("data-src"));
			entry.target.setAttribute("data-processed", true);
		});
	}
})();
</script>        
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>