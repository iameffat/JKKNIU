<!DOCTYPE html>
<html lang="zxx">
 
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>About JKKNIU</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

<style>
.myIframe {
  position: relative;
  padding-bottom: 150%;
  padding-top: 30px;
  height: 0;
  overflow: auto;
  -webkit-overflow-scrolling: touch;
  border: solid black 1px;
}
.myIframe iframe {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
</style>


</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->

	<!-- maintenance -->
	<div class="maintenance segments-page">
		<div class="container">
		
			<div class="content b-shadow">
			
	<h3><b>জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয় </b></h3>

<hr />

জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয় (জাককানইবি) বাংলাদেশের ময়মনসিংহ জেলায় অবস্থিত কাজী নজরুল ইসলামের স্মৃতি বিজড়িত ত্রিশাল উপজেলার নামাপাড়া বটতলায় অবস্থিত একটি পাবলিক বিশ্ববিদ্যালয়। এটি ময়মনসিংহ বিভাগে প্রতিষ্ঠিত প্রথম সাধারণ বিশ্ববিদ্যালয়। বিশ্ববিদ্যালয়টি <strong>২০০৬</strong> সালে প্রতিষ্ঠিত হয়। বিশ্ববিদ্যালয়টিতে বর্তমানে প্রায় আট হাজারের অধিক শিক্ষার্থী অধ্যয়নরত আছে।

<hr />

এটি ময়মনসিংহ শহর হতে প্রায় ২২ কিলোমিটার দূরে, ত্রিশাল বাসস্ট্যান্ড হতে ২ কিলোমিটার পশ্চিমদিকে (ফুলবাড়ীয়া অভিমুখে) নামাপাড়া বটতলায় অবস্থিত।রাজধানী শহর ঢাকা হতে এর দূরত্ব ১০০ কিলোমিটার।জাতীয় কবি কাজী নজরুল ইসলামের স্মৃতি বিজড়িত বটতলা ঘেঁষে বিশ্ববিদ্যালয়টি প্রতিষ্ঠিত।

<hr />

জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয়ে বর্তমানে <strong>৬টি অনুষদের</strong> অধীনে মোট <strong>২৪টি বিভাগ</strong> রয়েছে।
<table class="wikitable" style="background-color: #f8f9fa; border-collapse: collapse; border: 1px solid #a2a9b1; color: #202122; width: 100%; height: 744px;">
<tbody>
<tr style="height: 31px;">
<th style="background-color: #eaecf0; border: 1px solid #a2a9b1; padding: 0.2em 0.4em; text-align: center; height: 31px;">অনুষদের নাম</th>
<th style="background-color: #eaecf0; border: 1px solid #a2a9b1; padding: 0.2em 0.4em; text-align: center; height: 31px;">বিভাগসমূহ</th>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 124px;" rowspan="4">বিজ্ঞান ও প্রকৌশল অনুষদ</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">কম্পিউটার সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">ইলেকট্রিকাল এবং ইলেকট্রনিক ইঞ্জিনিয়ারিং বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">এনভায়রনমেন্টাল সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">পরিসংখ্যান বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 124px;" rowspan="5">ব্যবসায় প্রশাসন অনুষদ</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">হিসাববিজ্ঞান ও তথ্যপদ্ধতি বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">ফিন্যান্স ও ব্যাংকিং বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">মানব সম্পদ ব্যবস্থাপনা বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">ব্যবস্থাপনা বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">মার্কেটিং বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 217px;" rowspan="7">সামাজিক বিজ্ঞান অনুষদ</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">অর্থনীতি বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">লোকপ্রশাসন ও সরকার পরিচালনবিদ্যা বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">ফোকলোর বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">নৃবিজ্ঞান বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">পপুলেশন সায়েন্স বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">স্থানীয় সরকার এবং নগর উন্নয়ন বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">সমাজবিজ্ঞান বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 217px;" rowspan="6">কলা অনুষদ</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">বাংলা ভাষা ও সাহিত্য বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">ইংরেজি ভাষা ও সাহিত্য বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">সঙ্গীত বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">নাট্যকলা ও পরিবেশনাবিদ্যা বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">ফিল্ম এন্ড মিডিয়া বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">দর্শন বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;" rowspan="1">আইন অনুষদ</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">আইন ও বিচার বিভাগ</td>
</tr>
<tr style="height: 31px;">
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;" rowspan="1">চারুকলা অনুষদ</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em; height: 31px;">চারকলা বিভাগ</td>
</tr>
</tbody>
</table>
<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="অ্যাকাডেমিক_ভবন" class="mw-headline">অ্যাকাডেমিক ভবন</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ের অ্যাকাডেমিক কার্যক্রম পরিচালনার জন্য রয়েছে <strong>চারটি</strong> অ্যাকাডেমিক ভবন। ভবনগুলো হলো -</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১. কলাভবন</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২. বিজ্ঞান ভবন</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৩. সামাজিক বিজ্ঞান ভবন (দশতলাবিশিষ্ট)</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৪. ব্যবসায় প্রশাসন ভবন (দশতলাবিশিষ্ট)।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="উল্লেখযোগ্য_গবেষণা" class="mw-headline">উল্লেখযোগ্য গবেষণা</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ের এনভায়রনমেন্টাল সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগের শিক্ষক ড. আশরাফ আলী সিদ্দিকীর নেতৃত্বে একদল গবেষক কক্সবাজারে উচ্চামাত্রার ইউরেনিয়ামের সন্ধান পান।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="উল্লেখযোগ্য_গবেষণা" class="mw-headline">আবাসিক হলসমূহ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ে শিক্ষার্থীদের জন্য <strong>চারটি আবাসিক হল</strong> রয়েছে।</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">ছাত্রদের জন্য :</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১. অগ্নি-বীণা হল</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২. জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান হল (দশতলাবিশিষ্ট)।</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">ছাত্রীদের জন্য :</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১. দোলনচাঁপা হল</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২. বঙ্গমাতা বেগম ফজিলাতুন্নেছা মুজিব হল (দশতলাবিশিষ্ট)।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="ভাস্কর্যসমূহ" class="mw-headline">ভাস্কর্যসমূহ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১/  জাতির জনক বঙ্গবন্ধু শেখ মুজিবুর রহমান ভাস্কর্য</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২/  জাতীয় কবি কাজী নজরুল ইসলাম ভাস্কর্য</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৩/  জয় বাংলা ভাস্কর্য</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="স্মৃতিস্তম্ভ" class="mw-headline">স্মৃতিস্তম্ভ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ে রয়েছে কেন্দ্রীয় স্মৃতিস্তম্ভ; যার নামকরণ করা হয়েছে 'চির উন্নত মম শির'।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="ক্যাফেটেরিয়া" class="mw-headline">ক্যাফেটেরিয়া</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">কলা ভবনের নিকটে অবস্থিত বিশ্ববিদ্যালয়ের কেন্দ্রীয় ক্যাফেটেরিয়া 'চক্রবাক'।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="গ্রন্থাগার" class="mw-headline">গ্রন্থাগার</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ে রয়েছে পাঁচতলাবিশিষ্ট আধুনিক ও সু-সজ্জিত 'কেন্দ্রীয় গ্রন্থাগার'।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="খেলার_মাঠ" class="mw-headline">খেলার মাঠ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ে খেলাধুলা চর্চার জন্য রয়েছে সু-বিশাল মাঠ,যার নাম রাখা হয়েছে <strong>'শেখ রাসেল কেন্দ্রীয় খেলার মাঠ'</strong>।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="মসজিদ" class="mw-headline">মসজিদ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ে নির্মাণাধীন রয়েছে তিনতলা বিশিষ্ট আধুনিক স্থাপত্যশৈলীর 'কেন্দ্রীয় মসজিদ'।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="মুক্তমঞ্চ" class="mw-headline">মুক্তমঞ্চ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">যেহেতু বিশ্ববিদ্যালয়টি সাংস্কৃতিকভাবে অগ্রসরমান,সেহেতু এর অভ্যন্তরে রয়েছে 'গাহি সাম্যের গান মুক্তমঞ্চ'। এছাড়াও রয়েছে 'চুরুলিয়া মঞ্চ', যা কলা ভবনের নিকটে অবস্থিত। এছাড়া বিশ্ববিদ্যালয়ে পনেরোশত আসন বিশিষ্ট টিএসসি প্লাস মাল্টিপারপাস অডিটরিয়ামের কাজ শীঘ্রই শুরু হতে যাচ্ছে।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="মেডিকেল_সেন্টার" class="mw-headline">মেডিকেল সেন্টার</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ে শিক্ষার্থীদের স্বাস্থ্যসেবা নিশ্চিতের লক্ষ্যে নির্মাণ করা হয়েছে মেডিকেল সেন্টার,যার নামকরণ করা হয়েছে 'ব্যথার দান'।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="পরিবহন_ব্যবস্থা" class="mw-headline">পরিবহন ব্যবস্থা</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়ের শিক্ষার্থী, শিক্ষক, কর্মকতা ও কর্মচারীদের যাতায়াতের সুবিধার্থে রাখা হয়েছে নিজস্ব পরিবহন ব্যবস্থা; যা সার্বক্ষণিক তাদের গন্তব্যে পৌঁছানোর কাজে নিয়োজিত।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="ডরমিটরি" class="mw-headline">ডরমিটরি</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">শিক্ষক,কর্মকর্তাদের আবাসনের সু-ব্যবস্থার লক্ষ্যে নির্মিত হয়েছে ডরমিটরি; যা তাদের আবাসনের সু-প্রাপ্যতা নিশ্চিত করছে।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="ভিসি_বাংলো" class="mw-headline">ভিসি বাংলো</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">ক্যাম্পাসে উপাচার্য মহোদয়ের সার্বক্ষণিক তদারকি অব্যাহত রাখার লক্ষ্যে ক্যাম্পাসের অভ্যন্তরে অত্যন্ত মনোরম আবহে নির্মিত হয়েছে ভিসি বাংলো,যার নামকরণ করা হয়েছে <strong>'দুখু মিয়া বাংলো'</strong>।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="ভিসি_বাংলো" class="mw-headline">উপাচার্যের তালিকা</span></div>
<table class="wikitable" style="background-color: #f8f9fa; border-collapse: collapse; border: 1px solid #a2a9b1; color: #202122;  margin: 1em 0px;">
<tbody>
<tr>
<th style="background-color: #eaecf0; border: 1px solid #a2a9b1; padding: 0.2em 0.4em; text-align: center;">নাম</th>
<th style="background-color: #eaecf0; border: 1px solid #a2a9b1; padding: 0.2em 0.4em; text-align: center;">দায়িত্ব গ্রহণ</th>
<th style="background-color: #eaecf0; border: 1px solid #a2a9b1; padding: 0.2em 0.4em; text-align: center;">দায়িত্ব হস্থান্তর</th>
</tr>
<tr>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">এম. শামসুর রহমান</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">৭ জুন ২০০৬</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">১৯ এপ্রিল ২০০৯</td>
</tr>
<tr>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;"><span style="background-attachment: initial; background-clip: initial; background-image: none; background-origin: initial; background-position: initial; background-repeat: initial; background-size: initial;"><span style="color: black;">সৈয়দ গিয়াসউদ্দিন আহমেদ</span></span></td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">২২-এপ্রিল-২০০৯</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">১৩আগস্ট ২০১৩</td>
</tr>
<tr>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">অধ্যাপক ড. খোন্দকার আশরাফ হোসেন</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">২২ এপ্রিল ২০১৩</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">জুন ২০১৩</td>
</tr>
<tr>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;"><span style="background-attachment: initial; background-clip: initial; background-image: none; background-origin: initial; background-position: initial; background-repeat: initial; background-size: initial;"><span style="color: black;">অধ্যাপক ড. মোহিত উল আলম</span></span></td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">১৩ আগস্ট ২০১৩</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">১২ আগস্ট, ২০১৭</td>
</tr>
<tr>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">অধ্যাপক ড. এ এইচ এম মোস্তাফিজুর রহমান</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">১৩ নভেম্বর ২০১৭</td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;">১৩ নভেম্বর ২০২১</td>
</tr>
<tr>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;"><strong>অধ্যাপক ড. সৌমিত্র শেখর দে</strong></td>
<td style="border: 1px solid #a2a9b1; padding: 0.2em 0.4em;"><strong>১৫ ডিসেম্বর ২০২১</strong></td>
</tr>
</tbody>
</table>
<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="সংগঠনসমূহ" class="mw-headline">সংগঠনসমূহ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">বিশ্ববিদ্যালয়টি বিভিন্ন সংগঠনমূলক কাজে সক্রিয়। এখানে বছরের অধিকাংশ দিন বিভিন্ন ধরণের আনুষ্ঠানিকতা বা উৎসব অনুষ্ঠিত হয়। যেমন- চাকুরি মেলা, উচ্চশিক্ষা বিষয়ক সেমিনার, ক্রীড়া প্রতিযোগিতা, বিতর্ক প্রতিযোগিতা, ফটোগ্রাফি প্রতিযোগিতা, ফিল্ম ফেস্টিভাল, নাট্যোৎসব, স্কিলস হান্ট ইত্যাদি।</p>

<dl style="background-color: white; color: #202122;  margin-bottom: 0.5em; margin-top: 0.2em;">
 	<dt style="font-weight: bold; margin-bottom: 0.1em;">সাংবাদিক সংগঠন</dt>
</dl>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১. জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয় সাংবাদিক সমিতি</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২. জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয় প্রেসক্লাব।</p>

<dl style="background-color: white; color: #202122;  margin-bottom: 0.5em; margin-top: 0.2em;">
 	<dt style="font-weight: bold; margin-bottom: 0.1em;">সামাজিক, সাংস্কৃতিক ও পরিবেশবাদী সংগঠন</dt>
</dl>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১. জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয় ক্যারিয়ার ক্লাব</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২. জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয় স্কিল ডেভেলপমেন্ট ক্লাব</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৩. রংধনু</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৪. অরণ্য</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৫. কালের কণ্ঠ শুভ সংঘ</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৬. প্রথম আলো বন্ধুসভা</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৭. ডিবেটিং সোসাইটি</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৮. হাল্ট প্রাইজ</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">৯. গ্রীন ক্যাম্পাস</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১০. বারামখানা (লোকসঙ্গীত চর্চা কেন্দ্র)</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১১. স্টুডেন্টস' অ্যাসোসিয়েশন</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১২. জাককানইবি অ্যালামনাই অ্যাসোসিয়েশন</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৩. উদীচী</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৪. নির্ভয় ফাউন্ডেশন</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৫. জাককানইবি ড্যান্স ক্লাব</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৬.জাককানইবি ফিল্ম এন্ড ফটোগ্রাফি ক্লাব</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৭. রোটারেক্ট ক্লাব, জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয়</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৮. জাককানইবি মডেল ইউনাইটেড ন্যাশনস ক্লাব</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">১৯. উইমেন পিস ক্যাফে, জাককানইবি</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২০.জুম্ম স্টুডেন্টস এসোসিয়েশন</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২১. মশাল( পাঠচক্র )</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২২. 'মুক্তিযোদ্ধা সন্তান সংসদ'</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২৩. ডোনেট ফর লাইফ</p>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">২৪. অর্থ আলাপ সহ</p>
আরো অনেক সংগঠন রয়েছে।
<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="উৎসবসমূহ" class="mw-headline">উৎসবসমূহ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">যেহেতু বিশ্ববিদ্যালয়টি সাংস্কৃতিক মননে পরিচালিত হয়, সেহেতু এখানে সারাবছর-ই উৎসবের আমেজ লেগেই থাকে।বরাবরের ন্যায় প্রতিবছর-ই এখানে নজরুল জয়ন্তী, রবীন্দ্র জয়ন্তী ও বারামখানা'র উদ্যোগে লালন স্মরণোৎসব পালিত হয়।মাসব্যাপী নাট্যোসব, ফিল্ম ফ্যাস্টিভাল, পিঠা উৎসব, নজরুল বইমেলা, কুয়াশা উৎসব অন্যতম আকর্ষণীয় দিক।</p>

<div style="background-color: white; border-bottom: 1px solid #a2a9b1; font-weight: normal; line-height: 1.4em; margin: 1em 0px 0.25em; overflow: hidden; padding: 0px; text-align: center;"><span id="ক্যাম্পাসের_আকর্ষণীয়_স্থানসমূহ" class="mw-headline">ক্যাম্পাসের আকর্ষণীয় স্থানসমূহ</span></div>
<p style="background-color: white; color: #202122;  margin: 0.5em 0px;">শ্যাঁওড়াতলা/পেত্নীতলা, ক্যাফে রোড, জয় বাংলা চত্বর, গাহি সাম্যের গান মুক্তমঞ্চ, চুরুলিয়া মঞ্চ, নজরুল চত্বর, বঙ্গবন্ধু চত্বর, নতুন রাস্তা, চারুদ্বীপ, বটতলা, পদ্মপুকুর, পদ্মপুকুরে ভাসমান প্রমোদ তরী, সেন্ট্রাল ফিল্ড প্রভৃতি।</p>
<hr />
সোর্সঃ উইকিপিডিয়া।
	</div>
	</div>
	</div>
	
	
	
	<!-- end maintenance -->


	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>