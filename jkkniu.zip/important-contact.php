<!DOCTYPE html>
<html lang="zxx">
    
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Important Contacts</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
			<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->

	<!-- card -->
	<div class="wrap-card segments-page">
		<div class="container">
<div class="wrap-content b-shadow">
			
			
			<div class="container-pd">
				<div class="row">
				
					<div class="col-6 px-2">
					<a href="academic/dept.php">
						<div class="card b-shadow">
							<img src="images/teachers.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>একাডেমিক কর্ণার</b></h5>
								<p class="card-text">বিশ্ববিদ্যালয় শিক্ষকদের জরুরি মোবাইল নম্বর ও ইমেইল নম্বর সমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					<div class="col-6 px-2">
					<a href="administration/admin.php">
						<div class="card b-shadow">
							<img src="images/admini.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>প্রশাসনিক কর্ণার</b></h5>
								<p class="card-text">বিশ্ববিদ্যালয় প্রশাসনিক কর্মকর্তাদের জরুরি মোবাইল নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					
				</div>
                </div>		
			
			
			
			<div class="container-pd">
				<div class="row">
				
					<div class="col-6 px-2">
					<a href="ambulance.php">
						<div class="card b-shadow">
							<img src="images/ambulance.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>অ্যাম্বুলেন্স</b></h5>
								<p class="card-text">বিশ্ববিদ্যালয় ও আশেপাশের এলাকার জরুরি অ্যাম্বুলেন্স নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					<div class="col-6 px-2">
					<a href="fire-service.php">
						<div class="card b-shadow">
							<img src="images/fireservice.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>ফায়ার সার্ভিস</b></h5>
								<p class="card-text">বিশ্ববিদ্যালয় ও আশেপাশের এলাকার জরুরি ফায়ার সার্ভিস নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					
				</div>
                </div>				
					
					
				<div class="container-pd">
				<div class="row">	
					
					<div class="col-6 px-2">
					<a href="police-station.php">
						<div class="card b-shadow">
							<img src="images/police.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>পুলিশ স্টেশন</b></h5>
								<p class="card-text">বিশ্ববিদ্যালয় ও আশেপাশের এলাকার জরুরি পুলিশ স্টেশন নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					
					<div class="col-6 px-2">
					<a href="proctor-office.php">
						<div class="card b-shadow">
							<img src="images/proctor.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>প্রক্টর অফিস</b></h5>
								<p class="card-text">ক্যাম্পাসের নিরাপত্তা, শৃঙ্খলা নিশ্চিতে প্রক্টরিয়াল বডি কাজ করে থাকে।</p>
							</div>
						</div>
						</a>
					</div>
					
					</div>	
					</div>	
					
					
              <div class="container-pd">
				<div class="row">
					
					<div class="col-6 px-2">
					<a href="student-counciling.php">
						<div class="card b-shadow">
							<img src="images/student-coun.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>স্টুডেন্ট কাউন্সিলিং</b></h5>
								<p class="card-text">যেকোনো সমস্যায় শিক্ষার্থীদের পরামর্শ প্রদান করে থাকে।</p>
							</div>
						</div>
						</a>
					</div>
					<div class="col-6 px-2">
					<a href="./hall/hall-home.php">
						<div class="card b-shadow">
							<img src="images/halls.jpg" alt="">
							<div class="card-body">
								<h5 class="card-title"><b>ছাত্র/ছাত্রী হল</b></h5>
								<p class="card-text">বিশ্ববিদ্যালয়ের হলসমূহের গুরুত্বপূর্ণ নম্বরসমূহ।</p>
							</div>
						</div>
						</a>
					</div>
					
				</div>
			</div>
					
		</div>	
			
	</div>
	</div>
	<!-- end card -->

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>