<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Proctor Office</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
	
	<center>
	<div class="process segments-page">
		<div class="container">
		<div class="tabs2 b-shadow">
					<div class="content">
						<h4><b>প্রক্টর অফিস</b></h4>
					</div>
					</div></div>
				</div>
   </center>
   
	<!-- list -->
	<div class="list segments-page">
		<div class="container">
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/dept/s-cse/uzzal.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> প্রফেসর ড. উজ্জ্বল কুমার প্রধান</h5>
					<p>
					<i class="fa fa-briefcase"></i> প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭১৮০৪৫৩০৪">০১৭১৮০৪৫৩০৪</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:uzzalcseju@gmail.com">uzzalcseju@gmail.com</a>
					</p>
				</div>
			</div>
			
			
				<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> ড. মাে. কামাল উদ্দীন</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭১৯২৫৪৪২৬">০১৭১৯২৫৪৪২৬</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:mkumondal@gmail.com">mkumondal@gmail.com</a>
					</p>
				</div>
			</div>

			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব সবুজ চন্দ্র ভৌমিক, এসিএমএ</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৮৭৩১১৯২৬৬">০১৮৭৩১১৯২৬৬</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:sabujaisdu14@gmail.com">sabujaisdu14@gmail.com</a>
					</p>
				</div>
			</div>
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব মুহাম্মদ ইরফান আজিজ</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৮১৬৩৭৩২৩৯">০১৮১৬৩৭৩২৩৯</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:irfandu07@gmail.com">irfandu07@gmail.com</a>
					</p>
				</div>
			</div>
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব চন্দন কুমার পাল</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭২১০৮৯৮২৬">০১৭২১০৮৯৮২৬</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:paulchandan54@yahoo.com">paulchandan54@yahoo.com</a>
					</p>
				</div>
			</div>
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব মাে. রিয়াজুল ইসলাম</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭৬৪৪৪৮৯১৯">০১৭৬৪৪৪৮৯১৯</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:islamreaz8919@gmail.com">islamreaz8919@gmail.com</a>
					</p>
				</div>
			</div>
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব মাে. আসাদুজ্জামান</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭৩৫২৩৫১৬৮">০১৭৩৫২৩৫১৬৮</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:asaduzzamanlaw@gmail.com">asaduzzamanlaw@gmail.com</a>
					</p>
				</div>
			</div>
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব আসলাম মাহমুদ</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৯২৯৩২৭৭৯৩">০১৯২৯৩২৭৭৯৩</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:aslammahmudknu@gmail.com">aslammahmudknu@gmail.com</a>
					</p>
				</div>
			</div>
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব রােবাইয়া শাহরিন</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী প্রক্টর<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৯১১২৬১৯৭৬">০১৯১১২৬১৯৭৬</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:sunshine.rrl@gmail.com">sunshine.rrl@gmail.com</a>
					</p>
				</div>
			</div>
			

		</div>
		</div>
		</div>
	<!-- end list -->
       
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>