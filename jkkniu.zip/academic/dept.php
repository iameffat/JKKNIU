<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="../images/favicon.png">
	<title>Academic Corner</title>

	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.css">
	<link rel="stylesheet" href="../css/line-awesome.css">
	<link rel="stylesheet" href="../css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/owl.theme.default.min.css">
	<link rel="stylesheet" href="../css/animsition.css">
	<link rel="stylesheet" href="../css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
	
	<div class="tabs b-shadow"><center><p><b>পরিবর্তিত সকল তথ্য (বিশ্ববিদ্যালয় হতে প্রকাশিত) নতুন একাডেমিক ডায়েরি প্রকাশের সাথে সংগতি রেখে যুক্ত করা হবে।</b></p></center></div>
	
	<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>বিজ্ঞান ও প্রকৌশল অনুষদ</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../academic/s-dean.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ডিন অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
                       <div class="list segments-page2">
		<div class="container">
			<a href="../academic/s-cse.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> কম্পিউটার সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>				
		
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/s-eee.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ইলেকট্রিকাল এবং ইলেকট্রনিক ইঞ্জিনিয়ারিং বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
							
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/s-ese.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> এনভায়রনমেন্টাল সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
				<div class="list segments-page2">
		<div class="container">
			<a href="../academic/s-stat.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> পরিসংখ্যান বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>		
										
						
</div></div>
</div>
	
	
	
	
		<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>ব্যবসায় প্রশাসন অনুষদ</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../academic/b-dean.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ডিন অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
                       <div class="list segments-page2">
		<div class="container">
			<a href="../academic/b-ais.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> হিসাববিজ্ঞান ও তথ্যপদ্ধতি বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>				
		
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/b-finance.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ফিন্যান্স ও ব্যাংকিং বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
							
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/b-hrm.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> মানব সম্পদ ব্যবস্থাপনা বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
				<div class="list segments-page2">
		<div class="container">
			<a href="../academic/b-mgt.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ব্যবস্থাপনা বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	

<div class="list segments-page2">
		<div class="container">
			<a href="../coming.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> মার্কেটিং বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>
									
						
</div></div>
</div>
	
	
	
	<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>সামাজিক বিজ্ঞান অনুষদ</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-dean.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ডিন অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
                       <div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-economics.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> অর্থনীতি বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>				
		
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-pags.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> লোকপ্রশাসন ও সরকার পরিচালনবিদ্যা বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
							
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-folklore.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ফোকলোর বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
				<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-anthropology.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> নৃবিজ্ঞান বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	

<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-population-science.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> পপুলেশন সায়েন্স বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>
					
<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-lgud.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> স্থানীয় সরকার এবং নগর উন্নয়ন বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>
		
		
		<div class="list segments-page2">
		<div class="container">
			<a href="../academic/ss-sociology.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> সমাজবিজ্ঞান বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>


					
						
</div></div>
</div>
	
	
	
	
<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>কলা অনুষদ</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-dean.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ডিন অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
                       <div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-bangla.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> বাংলা ভাষা ও সাহিত্য বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>				
		
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-english.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ইংরেজি ভাষা ও সাহিত্য বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
							
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-music.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> সংগীত বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
				<div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-tps.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> নাট্যকলা ও পরিবেশনাবিদ্যা বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>		
							
				<div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-film.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ফিল্ম এন্ড মিডিয়া বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
					<div class="list segments-page2">
		<div class="container">
			<a href="../academic/a-philosophy.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> দর্শন বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	
					
						
</div></div>
</div>



<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>আইন অনুষদ</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../academic/l-dean.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ডিন অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
                       <div class="list segments-page2">
		<div class="container">
			<a href="../academic/l-law.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> আইন ও বিচার বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>												
						
</div></div>
</div>


<div class="process segments-page">
		<div class="container">
		<div class="tabs b-shadow">
					<div class="content">
						<h5><b><center>চারুকলা অনুষদ</center></b></h5>
					</div>

						<div class="list segments-page2">
		<div class="container">
			<a href="../academic/f-dean.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> ডিন অফিস</h5>
				</div>
			</div></a>
			</div>
		</div>
                       <div class="list segments-page2">
		<div class="container">
			<a href="../academic/f-fine.html"><div class="content2">
				<div class="list-text">
					<h5><i class="fa fa-arrow-circle-right"></i> চারকলা বিভাগ</h5>
				</div>
			</div></a>
			</div>
		</div>	






		
						
</div></div>
</div>



       
	<script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/lightbox.js"></script>
	<script src="../js/animsition.min.js"></script>
	<script src="../js/animsition-custom.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
    <script src="../js/styleswitcher.js"></script>
	<script src="../js/main.js"></script>

</body>
</html>