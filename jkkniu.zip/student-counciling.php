<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Student Counseling and Guidance</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->
	
	<center>
	<div class="process segments-page">
		<div class="container">
		<div class="tabs2 b-shadow">
					<div class="content">
						<h4><b>ছাত্র পরামর্শ ও নির্দেশনা দপ্তর</b></h4>
					</div>
					</div></div>
				</div>
   </center>
   
	<!-- list -->
	<div class="list segments-page">
		<div class="container">
			
			
			<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> ড. তপন কুমার সরকার</h5>
					<p>
					<i class="fa fa-briefcase"></i> পরিচালক<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭১২৪০১৭৪৮">০১৭১২৪০১৭৪৮</a><br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৬২১৬৮৪৮৪০">০১৬২১৬৮৪৮৪০</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:tksarker10@gmail.com">tksarker10@gmail.com</a>
					</p>
				</div>
			</div>
			
			
				<div class="content">
				<div class="list-img">
					<img src="images/avatar.jpg" alt="">
				</div>
				<div class="list-text">
				    <h5><i class="fa fa-user"></i> জনাব মােছা. আদিবা আক্তার</h5>
					<p>
					<i class="fa fa-briefcase"></i> সহকারী পরিচালক (কাউন্সিলিং সাইকোলােজিস্ট)<br/>
					<i class="fa fa-phone-square"></i> <a href="tel:০১৭০৪৮৭৬১১১">০১৭০৪৮৭৬১১১</a><br/>
					<i class="fa fa-envelope"></i> <a href="mailto:adipsy.cu@gmail.com">adipsy.cu@gmail.com</a>
					</p>
				</div>
			</div>

			
			

		</div>
		</div>
		</div>
	<!-- end list -->
       
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>