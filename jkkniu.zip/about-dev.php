<!DOCTYPE html>
<html lang="zxx">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>About Developer</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="index.php"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->


<!-- Image -->
<div class="profile segments-page">
<div class="profile-banner">
				<div class="content">
					<img src="images/effat.jpg" alt="">
					<h4>ইফফাত জাহান</h4>
					<span>(Developer of "JKKNIU APP") </span><br/>
					<span> www.effat.me</span>
				</div>
			</div>
</div>

	<!-- about -->
	<div class="abouts segments-page">
		<div class="container">
			<div class="about">
				<div class="content b-shadow">			
					<div class="text">
				
		<center><div class="social-link">
							<a href="https://facebook.com/iameffat" target="_blank"><i class="fa fa-facebook-f"></i></a>
							<a href="https://instagram.com/iameffat" target="_blank"><i class="fa fa-instagram"></i></a>
							<a href="https://www.linkedin.com/in/iameffat/" target="_blank"><i class="fa fa-linkedin"></i></a>
							
							<a href="mailto:mail@effat.me"><i class="fa fa-envelope"></i></a>
							<a href="https://effat.me" target="_blank"><i class="fa fa-link"></i></a>
							
						</div> </center>
					<center>
						<p>সেশনঃ ২০১৭-১৮,</p>
						<p>এনভায়রনমেন্টাল সায়েন্স এন্ড ইঞ্জিনিয়ারিং বিভাগ,</p>
						<p>জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয়।</p></center>
						<hr>
						<p>
						<b>কিছু কথাঃ</b>&nbsp;আমাদের প্রাণের "জাতীয় কবি কাজী নজরুল ইসলাম বিশ্ববিদ্যালয়" এর সকল তথ্য এক জায়গায় করার লক্ষ্যেই এই অ্যাপটি তৈরি করা।&nbsp; আমি চেষ্টা করেছি গুরুত্বপূর্ণ সকল তথ্য দেওয়ার জন্যে।&nbsp;  ভবিষ্যতে অ্যাপ আপডেট করার মাধ্যমে আরো ফিচারস এড করা হবে ইনশাল্লাহ।&nbsp; সকলের সাপোর্ট ও ফিডব্যাক আশা করছি।&nbsp; যেকোনো মতামত ও আপডেটেড তথ্য আমাকে জানাতে পারেন,&nbsp; আমি চেষ্টা করবো সেগুলো সংশোধন বা সংযোজন করার।&nbsp; ধন্যবাদ।
						</p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end about -->

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/lightbox.js"></script>
	<script src="js/animsition.min.js"></script>
	<script src="js/animsition-custom.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>