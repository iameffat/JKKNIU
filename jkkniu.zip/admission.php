<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Latest Notice Update</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

<style>
   #load{
    width:100%;
    height:100%;
    position:fixed;
    z-index:9999;
    background:url("images/loading.gif") no-repeat center center rgba(255,255,255,1)
}
</style>


</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	
	 <div id="load"></div>
    <div id="contents">
	
	<!-- navbar -->
	<div class="container">
			<div class="content">
			<h2><a href="" class="link-back"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	<!-- end navbar -->




	<!-- maintenance -->
	<div class="maintenance segments-page">
		<div class="container">
		
			<div class="content b-shadow">
			
	<h3><b> বিশ্ববিদ্যালয় নোটিশ আপডেট  </b></h3>
	<p>সাম্প্রতিক সকল আপডেট দেখতে ফোনের ইন্টারনেট কানেকশন চালু রেখে, পেইজটি ব্রাউজ করুন।</p>
	<hr>
		

<script language="JavaScript" src="https://www.feedroll.com/rssviewer/feed2js.php?src=https%3A%2F%2Ffeeds.feedburner.com%2FJKKNIU-Admission-Info&chan=&utf=y&html=a"  charset="UTF-8" type="text/javascript"></script>

<noscript>
<a href="https://www.feedroll.com/rssviewer/feed2js.php?src=https%3A%2F%2Ffeeds.feedburner.com%2FJKKNIU-Admission-Info&chan=&utf=y&html=y">View RSS feed</a>
</noscript>



	</div>
	</div>
	</div>
	
	</div>
	
	
	<!-- end maintenance -->
	
	<script>
	
	document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'interactive') {
       document.getElementById('contents').style.visibility="hidden";
  } else if (state == 'complete') {
      setTimeout(function(){
         document.getElementById('interactive');
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('contents').style.visibility="visible";
      },1000);
  }
}

</script>

	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>