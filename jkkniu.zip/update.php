<!DOCTYPE html>
<html lang="zxx">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="icon" href="images/favicon.png">
	<title>Update App Now</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.css">
	<link rel="stylesheet" href="css/line-awesome.css">
	<link rel="stylesheet" href="css/line-awesome-font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/animsition.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body class="animsition" onmousedown="return false" onselectstart="return false">
	
	<!-- navbar 
<div class="container">
			<div class="content">
			<h2><a href="index.php"><button class="button waves-effect floating-button blue b-shadow"><i class="fa fa-arrow-left"></i></button></a></h2>
			</div>
	    </div>
	 end navbar -->

	<!-- maintenance -->
	<div class="maintenance segments-page">
		<div class="container">
			<div class="content b-shadow">
				<ul>
					<li><i class="fa fa-bullhorn"></i></li>
					<li class="r-opponent"><i class="fa fa-level-down"></i></li>
				</ul>
<span style="font-size: 14pt;">			এপসটির <b>নতুন ভার্সন (২.৫)</b> রিলিজ হয়েছে। নতুন সব ফিচার পেতে এখনই প্লে স্টোর থেকে আপডেট করে নিন।
			<br>	<a href="https://play.google.com/store/apps/details?id=me.effat.jkkniu"><button class="button">Update from Here</button></a>
<br><br>
<h3><span style="color: #008000;"><strong>যা যা পরিবর্তন এসেছে!</strong></span></h3> </span>
<p>- App is now fully online based (Fetch data from online server).</p>
<p>- No more hassle to update the app because App data are continuously updating remotely via an online server.</p>
<p>- Added New Bus Schedule and other features.</p>
<p>- Added Android 12+ Support.</p>
<p>- Reduced App Size.</p>
<p>- Fixed Bug and other minor issues.</p>
<p>- More Features are coming...</p>
<br>
<span style="font-size: 14pt;">
<h3><span style="color: #008000;"><strong>এন্ড্রয়েড ১৩ ব্যবহারকারীদের জন্য বিশেষ নোটিশঃ</strong></span></h3>
এপের নোটিফিকেশন না পেলে। JKKNIU App এর <strong>App Info</strong> থেকে <strong>Notification Permission</strong> <span style="color: #008000;"><strong>Allow</strong></span> করে দিন। তাহলে বিশ্ববিদ্যালয়ের সকল নোটিশ, বিজ্ঞপ্তি আপনার ফোনে সরাসরি চলে যাবে।
		</span>	
			</div>
		</div>

	</div>
	<!-- end maintenance -->

	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/lightbox.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/animsition-custom.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/styleswitcher.js"></script>
	<script src="js/main.js"></script>

</body>
</html>